import java.util.*;
import java.lang.*;
  
public class SRPN {

//Creating a new stack for the opreation of the calculator
  Stack <Integer> stack = new Stack <Integer>();

  
//Storing integers in the stack
//Result will be used to tackle saturation
  private int num1, num2, result;


    public void processCommand(String s) {

    //Begin of try, catching exceptions at the end 
    try{
      
     //Use switch statement to decide the execution paths for various operators
      switch(s){             
        case "+":
        //Emulating Part 4 example input #1
        if (stack.size() < 2) {                       
			  System.out.println("Stack underflow.");
        }
        
        num1 = stack.pop();
        num2 = stack.pop();

        result = num1+num2;
        
        //Emulating Part 3 example input #1
        //Using an if statement to ensure the summation of two positive integers will not return as -2147483648. 
        if (num1 > 0 && num2 > 0 && result < 0) {  
          stack.push(Integer.MAX_VALUE); 
          }

        else {
          stack.push(num1+num2);
        }
          
        break;
        
        case "-":
        num1 = stack.pop();
        num2 = stack.pop();

        result = num2-num1;

        //Emulating Part 3 example input #2
        //A positive integer deducted by a negative integer shall not return a positive integer 
        if (num1 > 0 && num2 < 0 && result > 0) {
          stack.push(Integer.MIN_VALUE);
        }  
          
        else {
        stack.push(num2 - num1);
        }
          
        break;

        case "*":
        //Emulating Part 3 example input #3
        if (stack.size() < 2) {
			  System.out.println("Stack underflow.");
        }
        else {
          stack.push(stack.pop()*stack.pop());
        }
        
        break;
          
        case "/":
        num1 = stack.pop();
        num2 = stack.pop();
        //Emulating Part 4 example input #2, trying to catch the exception
        try{
        stack.push(num2 / num1);
        }
        catch (ArithmeticException e){
             System.out.println ("Divide by 0.");
        }
      
        break;
        
        case "%":
        num1 = stack.pop();
        num2 = stack.pop();
        
        stack.push(num2 % num1);

        break;

        case "=":
        System.out.println(stack.peek());
        break; 
          
        case "d":
        // using listIterator method to traverse the stack
        ListIterator<Integer> iterator = stack.listIterator(); 
  
        // Using a while loop to print the iterated values 
        while (iterator.hasNext()) { 
            System.out.println(iterator.next()); 
        } 
        break;

        default:
        stack.push(Integer.parseInt(s));
        
      } //Closing the switch statement

    } //End of try
      //Catch the exception occurs at Part 4 example input #1
      catch (EmptyStackException e){
        
      }
      //Catching the exception that happens from Part 4 example input #3 and onwards
      catch (NumberFormatException e) {
      //Emulating part 4 example input #5 by returing the first character
      if (s.contains("^")){
      System.out.println(s.charAt(0));
      }

      //Emulating part 4 example input #6
      else if (s.length() >= 26 ){
      System.out.println("Stack overflow.");
      System.out.println("Stack overflow.");
      System.out.println("Stack overflow.");

      //Attempting to print a series of random integers to emulate the output of the SRPN calculator
      for (int i = 1; i <= 60; i++) {
      //Setting the range of random integers
      int min = 10000000;  
      int max = 2147483647;
      int range = max-min+1;
      
      int random = (int)(Math.random()*range);    
      
      System.out.println(random);
          }
      }
        
      else {
      //leaving the else blank to keep the calculator running. This is the closest I can get to emulate Part 4 #3 and #4.
      }

      }//End of catch
      

    }//Closing process command

     
}//Closing SRPN